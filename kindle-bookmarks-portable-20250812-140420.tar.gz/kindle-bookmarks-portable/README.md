# Kindle Bookmarks Portable Bundle

This package contains a portable Python application that works in any Docker container with Python 3.7+.

## Files:
- `kindle_bookmarks.py` - Main Python script
- `run-portable.sh` - Portable runner script
- `config.json.example` - Configuration template
- `requirements-minimal.txt` - Minimal dependencies

## Usage:

### 1. Setup Configuration
```bash
cp config.json.example config.json
# Edit config.json with your settings
```

### 2. Run Portable Application
```bash
# The script will automatically create a virtual environment and install dependencies
./run-portable.sh
```

### 3. Docker Integration
Copy all files to your Docker container (must have Python 3.7+) and run:
```bash
./run-portable.sh
```

## Node-RED Integration
Use the `run-portable.sh` script in your Node-RED exec nodes:
```
/path/to/run-portable.sh
```

## Requirements:
- Python 3.7+ available in the container
- Internet access for initial dependency installation
- The script creates its own virtual environment automatically

## Benefits:
- Works on any architecture (ARM64, x86_64, etc.)
- No pre-compilation needed
- Automatic dependency management
- Cross-platform compatibility
