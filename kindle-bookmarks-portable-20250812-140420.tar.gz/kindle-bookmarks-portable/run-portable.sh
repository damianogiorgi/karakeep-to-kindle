#!/bin/bash

# Portable Kindle Bookmarks Runner
# This script sets up a minimal Python environment and runs the application

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="$SCRIPT_DIR/portable-venv"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

log() {
    echo -e "${BLUE}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1" >&2
}

success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Check if Python is available
check_python() {
    if command -v python3 >/dev/null 2>&1; then
        PYTHON_CMD="python3"
    elif command -v python >/dev/null 2>&1; then
        PYTHON_CMD="python"
    else
        error "Python not found. Please install Python 3.7+ in the container."
        exit 1
    fi
    
    # Check Python version
    local python_version=$($PYTHON_CMD -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
    log "Found Python $python_version"
    
    if ! $PYTHON_CMD -c "import sys; sys.exit(0 if sys.version_info >= (3, 7) else 1)" 2>/dev/null; then
        error "Python 3.7+ required, found $python_version"
        exit 1
    fi
}

# Create minimal virtual environment
setup_venv() {
    if [ ! -d "$VENV_DIR" ]; then
        log "Creating portable virtual environment..."
        $PYTHON_CMD -m venv "$VENV_DIR"
        
        # Activate and install minimal requirements
        source "$VENV_DIR/bin/activate"
        pip install --no-cache-dir -r "$SCRIPT_DIR/requirements-minimal.txt"
        success "Portable environment created"
    else
        log "Using existing portable environment"
        source "$VENV_DIR/bin/activate"
    fi
}

# Run the application
run_application() {
    log "Running Kindle Bookmarks (portable mode)..."
    
    # Check if config exists
    if [ ! -f "$SCRIPT_DIR/config.json" ]; then
        error "Configuration file not found at $SCRIPT_DIR/config.json"
        error "Please create config.json based on config.json.example"
        exit 1
    fi
    
    # Run with HTML format (most compatible)
    $PYTHON_CMD "$SCRIPT_DIR/kindle_bookmarks.py" \
        --config "$SCRIPT_DIR/config.json" \
        --format html \
        --compilation \
        --cleanup
    
    local exit_code=$?
    
    if [ $exit_code -eq 0 ]; then
        success "Kindle compilation completed successfully"
    else
        error "Kindle compilation failed with exit code $exit_code"
    fi
    
    return $exit_code
}

# Main execution
main() {
    log "=== Kindle Bookmarks Portable Runner ==="
    
    check_python
    setup_venv
    run_application
}

# Handle arguments
case "${1:-}" in
    --help|-h)
        echo "Kindle Bookmarks Portable Runner"
        echo ""
        echo "This script creates a minimal Python environment and runs the application."
        echo "It only requires Python 3.7+ to be available in the container."
        echo ""
        echo "Usage: $0"
        echo ""
        echo "Files needed:"
        echo "  - config.json (create from config.json.example)"
        echo "  - kindle_bookmarks.py"
        echo "  - requirements-minimal.txt"
        ;;
    *)
        main "$@"
        ;;
esac
